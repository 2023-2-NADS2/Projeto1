# pi-backend
projeto em desenvolvimento

## Instalações: ☕️
- Node - v16.13.0
- Mysql - 8.0.34
- Docker - v24.0.6 RECOMENDADO

## Dependencias:  ☕️
npm i express mysql dotenv hbs <br>
npm i --save nodemon  <br>
npm install mysql2  <br>
npm i bcryptjs <br>
npm i cookie-parser jsonwebtoken 
